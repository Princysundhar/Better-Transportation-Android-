package com.example.driveinn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SendRequest extends AppCompatActivity {
    EditText e1;
    Button b1;
    SharedPreferences sh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_request);
        e1=findViewById(R.id.editTextTextPersonName8);
        b1=findViewById(R.id.button12);
        sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ipaddress =e1.getText().toString();
                String url1 = "http://"+ipaddress+":8000";
                SharedPreferences.Editor ed=sh.edit();
                ed.putString("ip",ipaddress);
                ed.putString("url",url1);
                ed.commit();
            }

        });

    }
}